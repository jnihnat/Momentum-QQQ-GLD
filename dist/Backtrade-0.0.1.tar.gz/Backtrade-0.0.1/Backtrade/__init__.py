from .Financnik_SMO_PRO import *

if __name__ == '__main__':
    run()