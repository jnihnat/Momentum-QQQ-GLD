import Financnik_SMO_PRO as FSP

if __name__ == '__main__':
    FSP.run()