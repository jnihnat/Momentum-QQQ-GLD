Backtrading strategy 1.0
